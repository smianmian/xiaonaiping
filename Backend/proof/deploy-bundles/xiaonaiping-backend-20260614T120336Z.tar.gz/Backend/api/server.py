#!/usr/bin/env python3
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from api.storage import ObjectStorage, build_object_storage


STATIC_ROUTES = {
    "/privacy": ("privacy.html", "text/html; charset=utf-8"),
    "/terms": ("terms.html", "text/html; charset=utf-8"),
    "/support": ("support.html", "text/html; charset=utf-8"),
}
MAX_BACKUP_BYTES = 5 * 1024 * 1024
MAX_PHOTO_BYTES = 20 * 1024 * 1024
SESSION_TTL_SECONDS = 60 * 60 * 24 * 30
SAFE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


@dataclass(frozen=True)
class ServerConfig:
    data_dir: Path
    secret_key: str
    object_storage: ObjectStorage | None = None

    @property
    def database_path(self) -> Path:
        return self.data_dir / "xiaonaiping.sqlite3"

    @property
    def object_root(self) -> Path:
        return self.data_dir / "objects"

    def storage(self) -> ObjectStorage:
        return self.object_storage or build_object_storage(self.data_dir)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def unb64url(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value + padding)


def json_dumps_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def recovery_hash(secret_key: str, recovery_key: str) -> str:
    return hmac.new(secret_key.encode("utf-8"), recovery_key.encode("utf-8"), hashlib.sha256).hexdigest()


def sign(secret_key: str, value: bytes) -> str:
    return hmac.new(secret_key.encode("utf-8"), value, hashlib.sha256).hexdigest()


def make_session_token(secret_key: str, account_id: str) -> str:
    now = int(time.time())
    payload = {"sub": account_id, "iat": now, "exp": now + SESSION_TTL_SECONDS}
    encoded = b64url(json_dumps_bytes(payload))
    return f"{encoded}.{sign(secret_key, encoded.encode('ascii'))}"


def verify_session_token(secret_key: str, token: str) -> str | None:
    try:
        encoded, signature = token.split(".", 1)
    except ValueError:
        return None

    expected = sign(secret_key, encoded.encode("ascii"))
    if not hmac.compare_digest(expected, signature):
        return None

    try:
        payload = json.loads(unb64url(encoded))
    except (ValueError, json.JSONDecodeError):
        return None

    if not isinstance(payload, dict):
        return None
    if int(payload.get("exp", 0)) < int(time.time()):
        return None
    account_id = payload.get("sub")
    if not isinstance(account_id, str):
        return None
    return account_id


def connect(config: ServerConfig) -> sqlite3.Connection:
    config.data_dir.mkdir(parents=True, exist_ok=True)
    config.object_root.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(config.database_path)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.execute("PRAGMA journal_mode = WAL")
    ensure_schema(db)
    return db


def ensure_schema(db: sqlite3.Connection) -> None:
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS accounts (
            account_id TEXT PRIMARY KEY,
            recovery_hash TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            deleted_at TEXT
        );

        CREATE TABLE IF NOT EXISTS backups (
            account_id TEXT PRIMARY KEY REFERENCES accounts(account_id) ON DELETE CASCADE,
            payload BLOB NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS photos (
            account_id TEXT NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
            photo_id TEXT NOT NULL,
            content_type TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            sha256 TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (account_id, photo_id)
        );

        CREATE TABLE IF NOT EXISTS deletion_audit (
            audit_id TEXT PRIMARY KEY,
            account_id TEXT NOT NULL,
            deleted_at TEXT NOT NULL,
            backup_deleted INTEGER NOT NULL,
            photo_count INTEGER NOT NULL
        );
        """
    )
    db.commit()


class XiaoNaiPingHandler(BaseHTTPRequestHandler):
    server_version = "XiaoNaiPingAPI/1.0"
    config: ServerConfig

    def log_message(self, format: str, *args: Any) -> None:
        path = urlparse(self.path).path
        self.log_date_time_string()
        print(f"{self.address_string()} {self.command} {path} {args[1] if len(args) > 1 else ''}")

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/healthz":
            self.write_json({"status": "ok", "time": utc_now()})
            return
        if path in STATIC_ROUTES:
            self.handle_static(path)
            return

        account_id = self.require_account()
        if account_id is None:
            return

        if path == "/v1/account":
            self.handle_get_account(account_id)
        elif path == "/v1/backup":
            self.handle_get_backup(account_id)
        elif path == "/v1/photos":
            self.handle_list_photos(account_id)
        elif path.startswith("/v1/photos/"):
            self.handle_get_photo(account_id, path.removeprefix("/v1/photos/"))
        else:
            self.write_error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在。")

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path == "/v1/accounts":
            self.handle_create_account()
        elif path == "/v1/sessions/recover":
            self.handle_recover_session()
        else:
            self.write_error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在。")

    def do_PUT(self) -> None:
        account_id = self.require_account()
        if account_id is None:
            return

        path = urlparse(self.path).path
        if path == "/v1/backup":
            self.handle_put_backup(account_id)
        elif path.startswith("/v1/photos/"):
            self.handle_put_photo(account_id, path.removeprefix("/v1/photos/"))
        else:
            self.write_error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在。")

    def do_DELETE(self) -> None:
        account_id = self.require_account()
        if account_id is None:
            return

        path = urlparse(self.path).path
        if path == "/v1/account":
            self.handle_delete_account(account_id)
        elif path.startswith("/v1/photos/"):
            self.handle_delete_photo(account_id, path.removeprefix("/v1/photos/"))
        else:
            self.write_error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在。")

    def handle_create_account(self) -> None:
        account_id = str(uuid.uuid4())
        recovery_key = "xnp_" + secrets.token_urlsafe(24)
        created_at = utc_now()

        with connect(self.config) as db:
            db.execute(
                "INSERT INTO accounts(account_id, recovery_hash, created_at) VALUES (?, ?, ?)",
                (account_id, recovery_hash(self.config.secret_key, recovery_key), created_at),
            )
            db.commit()

        self.write_json(
            {
                "accountId": account_id,
                "sessionToken": make_session_token(self.config.secret_key, account_id),
                "recoveryKey": recovery_key,
                "createdAt": created_at,
            },
            status=HTTPStatus.CREATED,
        )

    def handle_recover_session(self) -> None:
        body = self.read_json(MAX_BACKUP_BYTES)
        if not isinstance(body, dict):
            self.write_error(HTTPStatus.BAD_REQUEST, "invalid_json", "请求体必须是 JSON 对象。")
            return

        recovery_key = body.get("recoveryKey")
        if not isinstance(recovery_key, str) or not recovery_key:
            self.write_error(HTTPStatus.BAD_REQUEST, "missing_recovery_key", "缺少恢复密钥。")
            return

        key_hash = recovery_hash(self.config.secret_key, recovery_key)
        with connect(self.config) as db:
            row = db.execute(
                "SELECT account_id, created_at FROM accounts WHERE recovery_hash = ? AND deleted_at IS NULL",
                (key_hash,),
            ).fetchone()

        if row is None:
            self.write_error(HTTPStatus.UNAUTHORIZED, "invalid_recovery_key", "恢复密钥无效或账号已删除。")
            return

        self.write_json(
            {
                "accountId": row["account_id"],
                "sessionToken": make_session_token(self.config.secret_key, row["account_id"]),
                "createdAt": row["created_at"],
            }
        )

    def handle_get_account(self, account_id: str) -> None:
        with connect(self.config) as db:
            row = db.execute(
                "SELECT account_id, created_at FROM accounts WHERE account_id = ? AND deleted_at IS NULL",
                (account_id,),
            ).fetchone()
        if row is None:
            self.write_error(HTTPStatus.UNAUTHORIZED, "account_deleted", "账号不存在或已删除。")
            return
        self.write_json({"accountId": row["account_id"], "createdAt": row["created_at"]})

    def handle_put_backup(self, account_id: str) -> None:
        payload = self.read_body(MAX_BACKUP_BYTES)
        try:
            json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self.write_error(HTTPStatus.BAD_REQUEST, "invalid_backup", "备份必须是 UTF-8 JSON。")
            return

        now = utc_now()
        with connect(self.config) as db:
            db.execute(
                """
                INSERT INTO backups(account_id, payload, updated_at) VALUES (?, ?, ?)
                ON CONFLICT(account_id) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at
                """,
                (account_id, payload, now),
            )
            db.commit()

        self.write_json({"updatedAt": now, "sizeBytes": len(payload)})

    def handle_get_backup(self, account_id: str) -> None:
        with connect(self.config) as db:
            row = db.execute(
                "SELECT payload, updated_at FROM backups WHERE account_id = ?",
                (account_id,),
            ).fetchone()
        if row is None:
            self.write_error(HTTPStatus.NOT_FOUND, "backup_not_found", "还没有云端备份。")
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("X-XNP-Updated-At", row["updated_at"])
        self.send_header("Content-Length", str(len(row["payload"])))
        self.end_headers()
        self.wfile.write(row["payload"])

    def handle_put_photo(self, account_id: str, photo_id: str) -> None:
        if not self.is_safe_id(photo_id):
            self.write_error(HTTPStatus.BAD_REQUEST, "invalid_photo_id", "照片 ID 不合法。")
            return

        content_type = self.headers.get("Content-Type") or "application/octet-stream"
        if content_type.split(";")[0].strip().lower() not in {"image/jpeg", "image/png", "application/octet-stream"}:
            self.write_error(HTTPStatus.UNSUPPORTED_MEDIA_TYPE, "unsupported_photo_type", "只允许上传 JPEG 或 PNG。")
            return

        payload = self.read_body(MAX_PHOTO_BYTES)
        digest = hashlib.sha256(payload).hexdigest()
        self.config.storage().put_photo(account_id, photo_id, payload, content_type)

        now = utc_now()
        with connect(self.config) as db:
            db.execute(
                """
                INSERT INTO photos(account_id, photo_id, content_type, size_bytes, sha256, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(account_id, photo_id) DO UPDATE SET
                    content_type = excluded.content_type,
                    size_bytes = excluded.size_bytes,
                    sha256 = excluded.sha256,
                    updated_at = excluded.updated_at
                """,
                (account_id, photo_id, content_type, len(payload), digest, now),
            )
            db.commit()

        self.write_json(
            {
                "photoId": photo_id,
                "updatedAt": now,
                "sizeBytes": len(payload),
                "sha256": digest,
            }
        )

    def handle_list_photos(self, account_id: str) -> None:
        with connect(self.config) as db:
            rows = db.execute(
                """
                SELECT photo_id, content_type, size_bytes, sha256, updated_at
                FROM photos
                WHERE account_id = ?
                ORDER BY updated_at DESC
                """,
                (account_id,),
            ).fetchall()

        self.write_json(
            {
                "photos": [
                    {
                        "photoId": row["photo_id"],
                        "contentType": row["content_type"],
                        "sizeBytes": row["size_bytes"],
                        "sha256": row["sha256"],
                        "updatedAt": row["updated_at"],
                    }
                    for row in rows
                ]
            }
        )

    def handle_get_photo(self, account_id: str, photo_id: str) -> None:
        if not self.is_safe_id(photo_id):
            self.write_error(HTTPStatus.BAD_REQUEST, "invalid_photo_id", "照片 ID 不合法。")
            return

        with connect(self.config) as db:
            row = db.execute(
                "SELECT content_type, size_bytes FROM photos WHERE account_id = ? AND photo_id = ?",
                (account_id, photo_id),
            ).fetchone()

        if row is None:
            self.write_error(HTTPStatus.NOT_FOUND, "photo_not_found", "照片不存在或已删除。")
            return
        payload = self.config.storage().get_photo(account_id, photo_id)
        if payload is None:
            self.write_error(HTTPStatus.NOT_FOUND, "photo_not_found", "照片不存在或已删除。")
            return

        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", row["content_type"])
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def handle_delete_photo(self, account_id: str, photo_id: str) -> None:
        if not self.is_safe_id(photo_id):
            self.write_error(HTTPStatus.BAD_REQUEST, "invalid_photo_id", "照片 ID 不合法。")
            return

        self.config.storage().delete_photo(account_id, photo_id)
        with connect(self.config) as db:
            db.execute("DELETE FROM photos WHERE account_id = ? AND photo_id = ?", (account_id, photo_id))
            db.commit()
        self.write_json({"photoId": photo_id, "deleted": True})

    def handle_static(self, path: str) -> None:
        file_name, content_type = STATIC_ROUTES[path]
        static_path = Path(__file__).resolve().parents[1] / "static" / file_name
        if not static_path.exists():
            self.write_error(HTTPStatus.NOT_FOUND, "static_not_found", "页面不存在。")
            return
        payload = static_path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "public, max-age=300")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def handle_delete_account(self, account_id: str) -> None:
        with connect(self.config) as db:
            photo_count = db.execute("SELECT COUNT(*) AS count FROM photos WHERE account_id = ?", (account_id,)).fetchone()[
                "count"
            ]
            had_backup = db.execute("SELECT 1 FROM backups WHERE account_id = ?", (account_id,)).fetchone() is not None
            now = utc_now()
            db.execute("DELETE FROM backups WHERE account_id = ?", (account_id,))
            db.execute("DELETE FROM photos WHERE account_id = ?", (account_id,))
            db.execute("UPDATE accounts SET deleted_at = ? WHERE account_id = ?", (now, account_id))
            db.execute(
                """
                INSERT INTO deletion_audit(audit_id, account_id, deleted_at, backup_deleted, photo_count)
                VALUES (?, ?, ?, ?, ?)
                """,
                (str(uuid.uuid4()), account_id, now, int(had_backup), int(photo_count)),
            )
            db.commit()

        self.config.storage().delete_account(account_id)

        self.write_json(
            {
                "accountId": account_id,
                "deletedAt": now,
                "backupDeleted": had_backup,
                "photoCountDeleted": photo_count,
            }
        )

    def require_account(self) -> str | None:
        authorization = self.headers.get("Authorization") or ""
        if not authorization.startswith("Bearer "):
            self.write_error(HTTPStatus.UNAUTHORIZED, "missing_token", "缺少登录令牌。")
            return None

        token = authorization.removeprefix("Bearer ").strip()
        account_id = verify_session_token(self.config.secret_key, token)
        if account_id is None:
            self.write_error(HTTPStatus.UNAUTHORIZED, "invalid_token", "登录令牌无效或已过期。")
            return None

        with connect(self.config) as db:
            row = db.execute(
                "SELECT account_id FROM accounts WHERE account_id = ? AND deleted_at IS NULL",
                (account_id,),
            ).fetchone()

        if row is None:
            self.write_error(HTTPStatus.UNAUTHORIZED, "account_deleted", "账号不存在或已删除。")
            return None
        return account_id

    def read_json(self, max_bytes: int) -> Any:
        payload = self.read_body(max_bytes)
        if not payload:
            return {}
        try:
            return json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None

    def read_body(self, max_bytes: int) -> bytes:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length > max_bytes:
            self.write_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, "body_too_large", "请求体过大。")
            raise ConnectionAbortedError("request body too large")
        return self.rfile.read(length)

    def write_json(self, value: Any, status: HTTPStatus = HTTPStatus.OK) -> None:
        payload = json_dumps_bytes(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def write_error(self, status: HTTPStatus, code: str, message: str) -> None:
        self.write_json({"error": {"code": code, "message": message}}, status=status)

    @staticmethod
    def is_safe_id(value: str) -> bool:
        return SAFE_ID_RE.match(value) is not None


def create_http_server(host: str, port: int, config: ServerConfig) -> ThreadingHTTPServer:
    class ConfiguredHandler(XiaoNaiPingHandler):
        pass

    effective_config = config if config.object_storage is not None else replace(
        config,
        object_storage=build_object_storage(config.data_dir),
    )
    ConfiguredHandler.config = effective_config
    connect(effective_config).close()
    return ThreadingHTTPServer((host, port), ConfiguredHandler)


def main() -> None:
    data_dir = Path(os.environ.get("XNP_DATA_DIR", ".xnp-data")).resolve()
    secret_key = os.environ.get("XNP_SECRET_KEY", "local-dev-change-me")
    host = os.environ.get("XNP_HOST", "127.0.0.1")
    port = int(os.environ.get("XNP_PORT", "8787"))
    server = create_http_server(host, port, ServerConfig(data_dir=data_dir, secret_key=secret_key))
    print(f"XiaoNaiPing API listening on http://{host}:{port}")
    server.serve_forever()


if __name__ == "__main__":
    main()
