# XiaoNaiPing Backend

This is the first-party minimal backend for the V1 App Store path. It only covers account recovery keys, authenticated backup/restore, private photo object storage, and account deletion.

It intentionally does not include an admin console, analytics, subscriptions, public sharing, or client-side cloud credentials.

## Local Run

```bash
cd Backend
XNP_SECRET_KEY=replace-in-private-deploy XNP_DATA_DIR=.xnp-data python3 api/server.py
```

The local API listens on `http://127.0.0.1:8787` by default.

## Required Endpoints

- `POST /v1/accounts`
- `POST /v1/sessions/recover`
- `GET /v1/account`
- `PUT /v1/backup`
- `GET /v1/backup`
- `PUT /v1/photos/{photoId}`
- `GET /v1/photos`
- `GET /v1/photos/{photoId}`
- `DELETE /v1/photos/{photoId}`
- `DELETE /v1/account`

All endpoints except account creation and recovery require `Authorization: Bearer <sessionToken>`.

## Storage

- SQLite stores accounts, latest JSON backup payloads, photo metadata, and deletion audit rows.
- In local/default mode, photo binaries are stored under `XNP_DATA_DIR/objects/{accountId}/photos`.
- In Huawei Cloud mode, set `XNP_STORAGE_BACKEND=huawei_obs` and configure the `HUAWEI_OBS_*` environment variables from a private env file.
- Account deletion marks the account deleted, removes backup rows, removes photo metadata, and deletes the account object directory.

## Verification

```bash
cd Backend
python3 -m unittest tests/test_api.py
python3 ../Backend/scripts/verify_release_flow.py --output ../Backend/proof/release-flow.json
```

`Backend/proof/release-flow.json` records a local release-flow proof covering account creation, backup upload/restore, photo upload/list/download, recovery key login, account deletion, and token rejection after deletion.

After deploying a real HTTPS API, run:

```bash
python3 Backend/scripts/verify_remote_api.py --base-url https://api.example.com --output Backend/proof/remote-api.json
python3 Backend/scripts/check_production_readiness.py --base-url https://api.example.com --require-huawei-obs --require-screenshots --output Backend/proof/production-readiness.json
```

Both the remote proof and the production readiness report must pass before App Store submission.

## Production Handoff

Production deployment must provide:

- A private `XNP_SECRET_KEY`.
- A private `XNP_DATA_DIR` with backups enabled.
- HTTPS termination and request size limits in the reverse proxy.
- A real API domain configured in the iOS Release build through `XNP_API_BASE_URL`.
- Object storage lifecycle, backup, and deletion verification evidence in the release proof pack.
- Optional Huawei Cloud OBS setup is documented in `Backend/deploy/huawei-obs.md`.

Build a secret-free deployment bundle for handoff:

```bash
python3 Backend/scripts/build_deploy_bundle.py --output-dir Backend/proof/deploy-bundles
```

The generated manifest records file hashes and confirms that private `.env` files are not included.
