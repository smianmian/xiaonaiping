# Huawei Cloud OBS Handoff

This handoff keeps production secrets out of the repository. Use it only in the private deployment workspace.

## Backend Mode

Set:

```bash
XNP_STORAGE_BACKEND=huawei_obs
HUAWEI_OBS_ACCESS_KEY_ID=...
HUAWEI_OBS_SECRET_ACCESS_KEY=...
HUAWEI_OBS_ENDPOINT=...
HUAWEI_OBS_BUCKET=...
HUAWEI_OBS_PREFIX=xiaonaiping
```

Install the optional SDK:

```bash
pip install -r Backend/requirements-obs.txt
```

## Bucket Rules

1. Use a private bucket.
2. Do not allow public object listing or public object reads.
3. Do not place baby names, birthdays, notes, or original filenames in object keys.
4. Keep server-side AK/SK only on the backend host or secret manager.
5. Keep iOS clients on the first-party API; do not give the app direct OBS write credentials.
6. Verify account deletion removes all objects under `HUAWEI_OBS_PREFIX/{accountId}/`.

## Evidence Required Before App Store Submit

1. API health check over HTTPS.
2. Release-flow verification against the production API:
   `python3 Backend/scripts/verify_remote_api.py --base-url https://api.example.com --output Backend/proof/remote-api.json`
3. Production readiness verification:
   `python3 Backend/scripts/check_production_readiness.py --base-url https://api.example.com --require-huawei-obs --require-screenshots --output Backend/proof/production-readiness.json`
4. Secret-free deployment bundle:
   `python3 Backend/scripts/build_deploy_bundle.py --output-dir Backend/proof/deploy-bundles`
5. OBS lifecycle and backup settings screenshot or exported policy.
6. Deletion proof showing account backup and photo objects are gone after `DELETE /v1/account`.
