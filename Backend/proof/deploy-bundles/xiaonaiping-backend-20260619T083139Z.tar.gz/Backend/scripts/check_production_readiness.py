#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


PLACEHOLDER_HOSTS = (
    "api.example.com",
    "example.com",
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
    "::1",
)

XNP_NAMESPACE_MARKERS = ("xiaonaiping", "xnp")

FORBIDDEN_SHARED_SERVICE_MARKERS = (
    "emotion",
    "emotion-isle",
    "emotion_isle",
    "yidaimao",
    "yi-gen-dai-mao",
    "daimao",
    "ydm",
    "一根呆毛",
    "情绪",
)

ISOLATION_ENV_NAMES = (
    "XNP_DATA_DIR",
    "XNP_MYSQL_HOST",
    "XNP_MYSQL_USER",
    "XNP_MYSQL_DATABASE",
    "HUAWEI_OBS_ENDPOINT",
    "HUAWEI_OBS_BUCKET",
    "HUAWEI_OBS_PREFIX",
    "XNP_SMS_WEBHOOK_URL",
)

REQUIRED_DOCS = {
    "privacyReview": "Docs/07_PrivacySecurity/PRIVACY_REVIEW.md",
    "sdkInventory": "Docs/07_PrivacySecurity/SDK_DATA_INVENTORY.md",
    "testPlan": "Docs/05_QA/TEST_PLAN.md",
    "releaseChecklist": "Docs/06_Release/RELEASE_CHECKLIST.md",
    "proofPack": "Docs/06_Release/PROOF_PACK.md",
    "regionalStrategy": "Docs/08_Release/REGIONAL_LAUNCH_STRATEGY.md",
    "appStoreMetadata": "Docs/08_Release/APP_STORE_METADATA.md",
    "appStorePrivacyLabel": "Docs/08_Release/APP_STORE_PRIVACY_LABEL.json",
    "appStoreSubmissionPacket": "Docs/08_Release/APP_STORE_SUBMISSION_PACKET.md",
    "privacyPolicyDraft": "Docs/08_Release/PRIVACY_POLICY_DRAFT.md",
    "termsDraft": "Docs/08_Release/TERMS_OF_USE_DRAFT.md",
    "screenshotPlan": "Docs/08_Release/SCREENSHOT_PLAN.md",
    "rollbackPlan": "Docs/06_Release/ROLLBACK_PLAN.md",
}

STATIC_PAGE_MARKERS = {
    "/privacy": "小奶瓶隐私政策",
    "/terms": "小奶瓶用户协议",
    "/support": "小奶瓶支持",
}

ACCEPTED_IPHONE_SCREENSHOT_SIZES = {
    (1260, 2736),
    (2736, 1260),
    (1290, 2796),
    (2796, 1290),
    (1320, 2868),
    (2868, 1320),
    (1284, 2778),
    (2778, 1284),
    (1242, 2688),
    (2688, 1242),
    (1179, 2556),
    (2556, 1179),
    (1206, 2622),
    (2622, 1206),
    (1170, 2532),
    (2532, 1170),
    (1125, 2436),
    (2436, 1125),
    (1080, 2340),
    (2340, 1080),
    (1242, 2208),
    (2208, 1242),
    (750, 1334),
    (1334, 750),
    (640, 1096),
    (640, 1136),
    (1136, 600),
    (1136, 640),
    (640, 920),
    (640, 960),
    (960, 600),
    (960, 640),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return ""


def parse_release_api_base_url(project_yml: Path) -> str:
    text = read_text(project_yml)
    lines = text.splitlines()
    in_release = False
    release_indent = 0

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        indent = len(line) - len(line.lstrip())
        if re.fullmatch(r"Release:\s*", stripped):
            in_release = True
            release_indent = indent
            continue
        if in_release and indent <= release_indent:
            break
        if in_release:
            match = re.search(r'XNP_API_BASE_URL:\s*"?([^"]*)"?\s*$', line)
            if match:
                return match.group(1).strip()
    return ""


def is_placeholder_url(value: str) -> bool:
    lower = value.lower()
    return any(host in lower for host in PLACEHOLDER_HOSTS)


def has_xnp_namespace(value: str) -> bool:
    lower = value.lower()
    return any(marker in lower for marker in XNP_NAMESPACE_MARKERS)


def forbidden_marker(value: str) -> str:
    lower = value.lower()
    for marker in FORBIDDEN_SHARED_SERVICE_MARKERS:
        if marker.lower() in lower:
            return marker
    return ""


def proof_passed(path: Path, require_https: bool = False) -> tuple[bool, str]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return False, f"missing {path}"
    except json.JSONDecodeError as error:
        return False, f"invalid JSON: {error}"

    checks = data.get("checks")
    failed_checks = data.get("failedChecks")
    api_base_url = data.get("apiBaseUrl", "")
    if require_https and not str(api_base_url).startswith("https://"):
        return False, f"proof apiBaseUrl is not https: {api_base_url}"
    if require_https and is_placeholder_url(str(api_base_url)):
        return False, f"proof apiBaseUrl is placeholder: {api_base_url}"
    if data.get("passed") is not True:
        return False, f"proof passed=false, failedChecks={failed_checks}"
    if not isinstance(checks, dict) or not checks:
        return False, "proof has no checks"
    failed = [name for name, passed in checks.items() if passed is not True]
    if failed:
        return False, "failed checks: " + ", ".join(failed)
    return True, f"passed {len(checks)} checks"


def shared_service_hits(effective_base_url: str) -> list[str]:
    values = {"effectiveApiBaseUrl": effective_base_url}
    for name in ISOLATION_ENV_NAMES:
        values[name] = os.environ.get(name, "")

    hits = []
    for name, value in values.items():
        marker = forbidden_marker(value)
        if marker:
            hits.append(f"{name} contains {marker}")
    return hits


def namespace_failures(require_huawei_obs: bool) -> list[str]:
    required_values = {
        "XNP_DATA_DIR": os.environ.get("XNP_DATA_DIR", ""),
        "XNP_MYSQL_USER": os.environ.get("XNP_MYSQL_USER", ""),
        "XNP_MYSQL_DATABASE": os.environ.get("XNP_MYSQL_DATABASE", ""),
    }
    obs_bucket = os.environ.get("HUAWEI_OBS_BUCKET", "")
    obs_prefix = os.environ.get("HUAWEI_OBS_PREFIX", "")
    if require_huawei_obs or obs_bucket:
        required_values["HUAWEI_OBS_BUCKET"] = obs_bucket
    if require_huawei_obs or obs_prefix:
        required_values["HUAWEI_OBS_PREFIX"] = obs_prefix

    return [
        name
        for name, value in required_values.items()
        if not value or not has_xnp_namespace(value)
    ]


def fetch_text(base_url: str, path: str) -> tuple[bool, str]:
    try:
        with urllib.request.urlopen(base_url.rstrip("/") + path, timeout=15) as response:
            body = response.read().decode("utf-8", errors="replace")
            return response.status < 300, body
    except urllib.error.URLError as error:
        return False, str(error)


def png_size(path: Path) -> tuple[int, int] | None:
    try:
        header = path.read_bytes()[:33]
    except OSError:
        return None
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        return None
    width = int.from_bytes(header[16:20], "big")
    height = int.from_bytes(header[20:24], "big")
    return width, height


def jpeg_size(path: Path) -> tuple[int, int] | None:
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if len(data) < 4 or data[:2] != b"\xff\xd8":
        return None

    index = 2
    while index + 9 < len(data):
        if data[index] != 0xFF:
            index += 1
            continue
        marker = data[index + 1]
        index += 2
        if marker in {0xD8, 0xD9}:
            continue
        if index + 2 > len(data):
            return None
        segment_length = int.from_bytes(data[index:index + 2], "big")
        if segment_length < 2 or index + segment_length > len(data):
            return None
        if marker in range(0xC0, 0xC4) or marker in range(0xC5, 0xC8) or marker in range(0xC9, 0xCC) or marker in range(0xCD, 0xD0):
            height = int.from_bytes(data[index + 3:index + 5], "big")
            width = int.from_bytes(data[index + 5:index + 7], "big")
            return width, height
        index += segment_length
    return None


def image_size(path: Path) -> tuple[int, int] | None:
    if path.suffix.lower() == ".png":
        return png_size(path)
    if path.suffix.lower() in {".jpg", ".jpeg"}:
        return jpeg_size(path)
    return None


def screenshot_evidence(path: Path) -> tuple[bool, str]:
    if not path.exists():
        return False, f"missing {path}"

    candidates = [file for file in path.rglob("*") if file.is_file() and file.suffix.lower() in {".png", ".jpg", ".jpeg"}]
    if not candidates:
        return False, f"no PNG/JPEG screenshots under {path}"

    details = []
    for file in candidates:
        size = image_size(file)
        if size is None:
            details.append(f"{file.name}: unreadable")
            continue
        details.append(f"{file.name}: {size[0]}x{size[1]}")
        if size in ACCEPTED_IPHONE_SCREENSHOT_SIZES:
            return True, "; ".join(details)
    return False, "; ".join(details)



class Report:
    def __init__(self) -> None:
        self.checks: dict[str, dict[str, Any]] = {}

    def add(self, name: str, passed: bool, evidence: str, required: bool = True) -> None:
        self.checks[name] = {
            "passed": passed,
            "required": required,
            "evidence": evidence,
        }

    def to_dict(self, started_at: str, completed_at: str) -> dict[str, Any]:
        failed_required = [
            name
            for name, check in self.checks.items()
            if check["required"] and check["passed"] is not True
        ]
        return {
            "startedAt": started_at,
            "completedAt": completed_at,
            "ready": not failed_required,
            "failedRequiredChecks": failed_required,
            "checks": self.checks,
        }


def build_report(args: argparse.Namespace) -> dict[str, Any]:
    started_at = utc_now()
    root = Path(args.repo_root).resolve()
    report = Report()

    project_release_url = parse_release_api_base_url(root / "App/iOS/project.yml")
    effective_base_url = args.base_url or os.environ.get("XNP_API_BASE_URL") or project_release_url
    base_source = "--base-url" if args.base_url else "XNP_API_BASE_URL env" if os.environ.get("XNP_API_BASE_URL") else "App/iOS/project.yml Release"

    report.add(
        "productionApiBaseUrlPresent",
        bool(effective_base_url),
        f"{base_source}: {effective_base_url or '<empty>'}",
    )
    report.add(
        "productionApiBaseUrlUsesHttps",
        effective_base_url.startswith("https://"),
        effective_base_url or "<empty>",
    )
    report.add(
        "productionApiBaseUrlNotPlaceholder",
        bool(effective_base_url) and not is_placeholder_url(effective_base_url),
        effective_base_url or "<empty>",
    )

    secret_key = os.environ.get("XNP_SECRET_KEY", "")
    report.add(
        "productionSecretConfigured",
        len(secret_key) >= 32 and "change" not in secret_key.lower() and "replace" not in secret_key.lower(),
        "XNP_SECRET_KEY is set with production-looking length" if secret_key else "XNP_SECRET_KEY is missing",
    )
    data_dir = os.environ.get("XNP_DATA_DIR", "")
    report.add(
        "productionDataDirConfigured",
        bool(data_dir),
        "XNP_DATA_DIR is set" if data_dir else "XNP_DATA_DIR is missing",
    )

    database_backend = os.environ.get("XNP_DATABASE_BACKEND", "").strip().lower()
    report.add(
        "mysqlDatabaseSelected",
        database_backend == "mysql",
        f"XNP_DATABASE_BACKEND={database_backend or '<empty>'}",
    )
    mysql_required_env = [
        "XNP_MYSQL_HOST",
        "XNP_MYSQL_USER",
        "XNP_MYSQL_PASSWORD",
        "XNP_MYSQL_DATABASE",
    ]
    missing_mysql = [name for name in mysql_required_env if not os.environ.get(name)]
    report.add(
        "mysqlDatabaseEnvPresent",
        not missing_mysql,
        "missing: " + ", ".join(missing_mysql) if missing_mysql else "all required XNP_MYSQL_* variables are set",
    )

    storage_backend = os.environ.get("XNP_STORAGE_BACKEND", "").strip().lower()
    report.add(
        "huaweiObsSelected",
        storage_backend == "huawei_obs",
        f"XNP_STORAGE_BACKEND={storage_backend or '<empty>'}",
        required=args.require_huawei_obs,
    )
    huawei_required_env = [
        "HUAWEI_OBS_ACCESS_KEY_ID",
        "HUAWEI_OBS_SECRET_ACCESS_KEY",
        "HUAWEI_OBS_ENDPOINT",
        "HUAWEI_OBS_BUCKET",
    ]
    missing_huawei = [name for name in huawei_required_env if not os.environ.get(name)]
    report.add(
        "huaweiObsEnvPresent",
        not missing_huawei,
        "missing: " + ", ".join(missing_huawei) if missing_huawei else "all required HUAWEI_OBS_* variables are set",
        required=args.require_huawei_obs,
    )

    sms_provider = os.environ.get("XNP_SMS_PROVIDER", "").strip()
    sms_secret = os.environ.get("XNP_SMS_SECRET", "").strip()
    sms_webhook_url = os.environ.get("XNP_SMS_WEBHOOK_URL", "").strip()
    sms_missing = []
    if sms_provider != "webhook":
        sms_missing.append("XNP_SMS_PROVIDER=webhook")
    if not sms_secret:
        sms_missing.append("XNP_SMS_SECRET")
    if not sms_webhook_url:
        sms_missing.append("XNP_SMS_WEBHOOK_URL")
    report.add(
        "phoneLoginProviderConfigured",
        not sms_missing,
        "SMS webhook provider is configured" if not sms_missing else "missing: " + ", ".join(sms_missing),
    )

    wechat_app_id = os.environ.get("XNP_WECHAT_APP_ID", "").strip()
    wechat_app_secret = os.environ.get("XNP_WECHAT_APP_SECRET", "").strip()
    report.add(
        "wechatLoginProviderConfigured",
        bool(wechat_app_id and wechat_app_secret),
        "XNP_WECHAT_APP_ID and XNP_WECHAT_APP_SECRET are set" if wechat_app_id and wechat_app_secret else "missing XNP_WECHAT_APP_ID or XNP_WECHAT_APP_SECRET",
    )

    admin_token = os.environ.get("XNP_ADMIN_TOKEN", "")
    report.add(
        "privateOperationsDashboardConfigured",
        len(admin_token) >= 32,
        "XNP_ADMIN_TOKEN is set with production-looking length" if admin_token else "XNP_ADMIN_TOKEN is missing",
    )

    namespace_missing = namespace_failures(args.require_huawei_obs)
    report.add(
        "xiaonaipingProductionNamespaceConfigured",
        not namespace_missing,
        "missing xiaonaiping/xnp namespace in: " + ", ".join(namespace_missing)
        if namespace_missing
        else "data directory, MySQL identity, and object storage namespace are xiaonaiping-specific",
    )

    shared_hits = shared_service_hits(effective_base_url)
    report.add(
        "sharedServiceNamespaceRejected",
        not shared_hits,
        "; ".join(shared_hits) if shared_hits else "no Emotion/YDM/Daimao namespace markers in deployment values",
    )

    for check_name, relative_path in REQUIRED_DOCS.items():
        path = root / relative_path
        report.add(check_name + "Exists", path.exists(), relative_path)

    app_metadata = read_text(root / "Docs/08_Release/APP_STORE_METADATA.md")
    report.add(
        "appStoreUrlsFinalized",
        bool(app_metadata) and "api.example.com" not in app_metadata,
        "APP_STORE_METADATA.md still contains api.example.com" if "api.example.com" in app_metadata else "no placeholder App Store URL found",
    )

    local_passed, local_evidence = proof_passed(root / "Backend/proof/release-flow.json")
    report.add("localReleaseFlowProofPassed", local_passed, local_evidence)

    remote_passed, remote_evidence = proof_passed(root / args.remote_proof, require_https=True)
    report.add("remoteReleaseFlowProofPassed", remote_passed, remote_evidence)

    screenshot_path = root / args.screenshot_dir
    screenshot_passed, screenshot_detail = screenshot_evidence(screenshot_path)
    report.add(
        "appStoreScreenshotsCaptured",
        screenshot_passed,
        screenshot_detail,
        required=args.require_screenshots,
    )

    if args.live_check:
        for path, marker in STATIC_PAGE_MARKERS.items():
            ok, body_or_error = fetch_text(effective_base_url, path) if effective_base_url else (False, "missing base URL")
            report.add(
                "live" + path.title().replace("/", "") + "Available",
                ok and marker in body_or_error,
                path if ok else body_or_error,
            )

    return report.to_dict(started_at, utc_now())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=str(repo_root()))
    parser.add_argument("--base-url", default="")
    parser.add_argument("--remote-proof", default="Backend/proof/remote-api.json")
    parser.add_argument("--screenshot-dir", default="Docs/08_Release/Screenshots")
    parser.add_argument("--output", default="Backend/proof/production-readiness.json")
    parser.add_argument("--require-huawei-obs", action="store_true")
    parser.add_argument("--require-screenshots", action="store_true")
    parser.add_argument("--live-check", action="store_true")
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()

    result = build_report(args)
    output_path = Path(args.output)
    if not output_path.is_absolute():
        output_path = Path(args.repo_root) / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if result["ready"]:
        print(f"production readiness passed: {output_path}")
        return

    failed = ", ".join(result["failedRequiredChecks"])
    print(f"production readiness incomplete: {output_path}", file=sys.stderr)
    print(f"failed required checks: {failed}", file=sys.stderr)
    if not args.allow_incomplete:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
