#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage: run_launch_readiness.sh [options]

Run XiaoNaiPing launch-readiness checks and regenerate proof files in one pass.

Options:
  --repo-root PATH            Repository root (default: script directory's parent)
  --base-url URL              Public API base URL for remote checks
                              (default: https://api.mewpow.com/xiaonaiping)
  --env-file PATH             Private production .env (optional, loaded into env)
  --app-path PATH             XiaoNaiPing.app for iOS bundle check
  --live-check                Enable live auth-provider checks that hit production APIs
  --skip-ios-bundle            Skip iOS .app bundle check
  --help                      Show help

Examples:
  Backend/scripts/run_launch_readiness.sh \
    --env-file /srv/xiaonaiping/private/xiaonaiping-api.env \
    --base-url https://api.mewpow.com/xiaonaiping \
    --live-check
USAGE
}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

BASE_URL="https://api.mewpow.com/xiaonaiping"
ENV_FILE=""
APP_PATH=""
LIVE_CHECK=0
SKIP_IOS_BUNDLE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo-root)
      REPO_ROOT="$2"
      shift 2
      ;;
    --base-url)
      BASE_URL="$2"
      shift 2
      ;;
    --env-file)
      ENV_FILE="$2"
      shift 2
      ;;
    --app-path)
      APP_PATH="$2"
      shift 2
      ;;
    --live-check)
      LIVE_CHECK=1
      shift
      ;;
    --skip-ios-bundle)
      SKIP_IOS_BUNDLE=1
      shift
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      echo "unknown argument: $1" >&2
      usage
      exit 1
      ;;
  esac
done

cd "$REPO_ROOT"

if [[ -n "$ENV_FILE" ]]; then
  if [[ ! -f "$ENV_FILE" ]]; then
    echo "env file not found: $ENV_FILE" >&2
    exit 1
  fi

  set -a
  # shellcheck disable=SC1090
  source "$ENV_FILE"
  set +a
fi

run_or_fail() {
  local name="$1"
  shift
  if "$@" >/tmp/xnp-launch-step.log 2>&1; then
    echo "[ok] $name"
  else
    echo "[warn] $name (failed). tail:"
    echo "---"
    cat /tmp/xnp-launch-step.log
    echo "---"
    FAILED=1
  fi
}

publish_latest_proof() {
  local source="$1"
  local target="$2"
  if [[ -f "$source" ]]; then
    cp "$source" "$target"
  fi
}

FAILED=0
TIMESTAMP="$(date -u +%Y%m%dT%H%M%SZ)"
REMOTE_PROOF="Backend/proof/remote-api-${TIMESTAMP}.json"
STORAGE_PROOF="Backend/proof/storage-backend-${TIMESTAMP}.json"
AUTH_PROOF="Backend/proof/auth-providers-${TIMESTAMP}.json"
DIAG_PROOF="Backend/proof/diagnostics-redaction-${TIMESTAMP}.json"
PUBLIC_PAGES_PROOF="Backend/proof/public-pages-${TIMESTAMP}.json"
REVIEW_NOTES_PROOF="Backend/proof/review-notes-${TIMESTAMP}.json"
LEGAL_DRAFTS_PROOF="Backend/proof/legal-drafts-${TIMESTAMP}.json"
UNIVERSAL_LINKS_PROOF="Backend/proof/universal-links-${TIMESTAMP}.json"
APP_STORE_EVIDENCE="Backend/proof/app-store-evidence-${TIMESTAMP}.json"
IOS_RELEASE_PROOF="Backend/proof/ios-release-readiness-${TIMESTAMP}.json"
IOS_APP_BUNDLE_PROOF="Backend/proof/ios-app-bundle-${TIMESTAMP}.json"
APP_STORE_ASSETS="Backend/proof/app-store-assets-${TIMESTAMP}.json"
DEPLOY_PROOF="Backend/proof/huawei-baota-deploy-${TIMESTAMP}.json"
PRODUCTION_PROOF="Backend/proof/production-readiness-${TIMESTAMP}.json"

DEPLOY_PROOF_ARGS=(
  --allow-missing-env-file
  --output "$DEPLOY_PROOF"
  --base-url "$BASE_URL"
  --service-active
  --public-internal-blocked
)

run_or_fail "collect deployment proof" \
  python3 Backend/scripts/collect_deployment_proof.py \
  "${DEPLOY_PROOF_ARGS[@]}"
publish_latest_proof "$DEPLOY_PROOF" "Backend/proof/huawei-baota-deploy.json"

run_or_fail "verify remote API" \
  python3 Backend/scripts/verify_remote_api.py \
  --base-url "$BASE_URL" \
  --output "$REMOTE_PROOF"
publish_latest_proof "$REMOTE_PROOF" "Backend/proof/remote-api.json"

run_or_fail "verify storage backend" \
  python3 Backend/scripts/verify_storage_backend.py \
  --output "$STORAGE_PROOF"
publish_latest_proof "$STORAGE_PROOF" "Backend/proof/storage-backend.json"

if [[ $LIVE_CHECK -eq 1 ]]; then
  run_or_fail "verify auth providers" \
    python3 Backend/scripts/verify_auth_providers.py \
    --live-check \
    --output "$AUTH_PROOF"
else
  run_or_fail "verify auth providers" \
    python3 Backend/scripts/verify_auth_providers.py \
    --output "$AUTH_PROOF"
fi
publish_latest_proof "$AUTH_PROOF" "Backend/proof/auth-providers.json"

run_or_fail "check diagnostics redaction" \
  python3 Backend/scripts/check_diagnostics_redaction.py \
  --output "$DIAG_PROOF"
publish_latest_proof "$DIAG_PROOF" "Backend/proof/diagnostics-redaction.json"

run_or_fail "check public pages" \
  python3 Backend/scripts/check_public_pages.py \
  --output "$PUBLIC_PAGES_PROOF"
publish_latest_proof "$PUBLIC_PAGES_PROOF" "Backend/proof/public-pages.json"

run_or_fail "check review notes" \
  python3 Backend/scripts/check_review_notes.py \
  --output "$REVIEW_NOTES_PROOF"
publish_latest_proof "$REVIEW_NOTES_PROOF" "Backend/proof/review-notes.json"

run_or_fail "check legal drafts" \
  python3 Backend/scripts/check_legal_drafts.py \
  --output "$LEGAL_DRAFTS_PROOF"
publish_latest_proof "$LEGAL_DRAFTS_PROOF" "Backend/proof/legal-drafts.json"

run_or_fail "check universal links" \
  python3 Backend/scripts/check_universal_links.py \
  --output "$UNIVERSAL_LINKS_PROOF"
publish_latest_proof "$UNIVERSAL_LINKS_PROOF" "Backend/proof/universal-links.json"

run_or_fail "check app store evidence" \
  python3 Backend/scripts/check_app_store_evidence.py \
  --allow-incomplete \
  --output "$APP_STORE_EVIDENCE"
publish_latest_proof "$APP_STORE_EVIDENCE" "Backend/proof/app-store-evidence.json"

run_or_fail "check iOS release readiness" \
  python3 Backend/scripts/check_ios_release_readiness.py \
  --allow-incomplete \
  --output "$IOS_RELEASE_PROOF"
publish_latest_proof "$IOS_RELEASE_PROOF" "Backend/proof/ios-release-readiness.json"

if [[ $SKIP_IOS_BUNDLE -eq 0 && -n "$APP_PATH" ]]; then
  run_or_fail "check iOS app bundle" \
    python3 Backend/scripts/check_ios_app_bundle.py \
    --app "$APP_PATH" \
    --allow-incomplete \
    --output "$IOS_APP_BUNDLE_PROOF"
  publish_latest_proof "$IOS_APP_BUNDLE_PROOF" "Backend/proof/ios-app-bundle.json"
elif [[ $SKIP_IOS_BUNDLE -eq 1 ]]; then
  echo "[skip] iOS app bundle check"
else
  echo "[skip] iOS app bundle check (pass --app-path to include)"
fi

IOS_APP_BUNDLE_PROOF_FOR_PROD="$IOS_APP_BUNDLE_PROOF"
if [[ ! -f "$IOS_APP_BUNDLE_PROOF_FOR_PROD" ]]; then
  IOS_APP_BUNDLE_PROOF_FOR_PROD="Backend/proof/ios-app-bundle.json"
fi

run_or_fail "check App Store assets" \
  python3 Backend/scripts/check_app_store_assets.py \
  --output "$APP_STORE_ASSETS"
publish_latest_proof "$APP_STORE_ASSETS" "Backend/proof/app-store-assets.json"

PROD_ARGS=(
  --base-url "$BASE_URL"
  --deployment-proof "$DEPLOY_PROOF"
  --remote-proof "$REMOTE_PROOF"
  --storage-proof "$STORAGE_PROOF"
  --ios-release-proof "$IOS_RELEASE_PROOF"
  --app-store-assets-proof "$APP_STORE_ASSETS"
  --auth-providers-proof "$AUTH_PROOF"
  --diagnostics-redaction-proof "$DIAG_PROOF"
  --public-pages-proof "$PUBLIC_PAGES_PROOF"
  --review-notes-proof "$REVIEW_NOTES_PROOF"
  --legal-drafts-proof "$LEGAL_DRAFTS_PROOF"
  --universal-links-proof "$UNIVERSAL_LINKS_PROOF"
  --app-store-evidence "$APP_STORE_EVIDENCE"
  --require-huawei-obs
  --require-screenshots
  --require-app-store-evidence
  --output "$PRODUCTION_PROOF"
  --allow-incomplete
)
if [[ $LIVE_CHECK -eq 1 ]]; then
  PROD_ARGS+=(--live-check)
fi

if [[ -f "$IOS_APP_BUNDLE_PROOF_FOR_PROD" ]]; then
  PROD_ARGS+=(--ios-app-bundle-proof "$IOS_APP_BUNDLE_PROOF_FOR_PROD")
fi

run_or_fail "check production readiness" \
  python3 Backend/scripts/check_production_readiness.py "${PROD_ARGS[@]}"
publish_latest_proof "$PRODUCTION_PROOF" "Backend/proof/production-readiness.json"

cat <<SUMMARY

Launch readiness checks complete. Proof outputs refreshed:
  production: ${PRODUCTION_PROOF}
  ios-release: ${IOS_RELEASE_PROOF}
  auth-providers: ${AUTH_PROOF}
  app-store-evidence: ${APP_STORE_EVIDENCE}
  deployment: ${DEPLOY_PROOF}
  remote-api: ${REMOTE_PROOF}
SUMMARY

if [[ $FAILED -eq 1 ]]; then
  echo "Some checks failed; do not treat this as submission-ready yet."
  exit 1
fi

echo "All checks command steps ran successfully."
