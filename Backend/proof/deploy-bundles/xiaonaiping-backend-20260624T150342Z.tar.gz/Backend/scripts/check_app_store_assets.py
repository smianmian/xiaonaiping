#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ACCEPTED_IPHONE_SCREENSHOT_SIZES = {
    (1260, 2736),
    (2736, 1260),
    (1290, 2796),
    (2796, 1290),
    (1320, 2868),
    (2868, 1320),
    (1284, 2778),
    (2778, 1284),
    (1242, 2688),
    (2688, 1242),
    (1179, 2556),
    (2556, 1179),
    (1206, 2622),
    (2622, 1206),
    (1170, 2532),
    (2532, 1170),
    (1125, 2436),
    (2436, 1125),
    (1080, 2340),
    (2340, 1080),
    (1242, 2208),
    (2208, 1242),
    (750, 1334),
    (1334, 750),
    (640, 1096),
    (640, 1136),
    (1136, 600),
    (1136, 640),
    (640, 920),
    (640, 960),
    (960, 600),
    (960, 640),
}

PNG_COLOR_TYPES_WITH_ALPHA = {4, 6}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def png_info(path: Path) -> dict[str, Any]:
    try:
        data = path.read_bytes()[:33]
    except OSError as error:
        return {"valid": False, "error": str(error)}
    if len(data) < 26 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        return {"valid": False, "error": "not a PNG with IHDR header"}
    return {
        "valid": True,
        "width": int.from_bytes(data[16:20], "big"),
        "height": int.from_bytes(data[20:24], "big"),
        "bitDepth": data[24],
        "colorType": data[25],
    }


def screenshot_files(path: Path) -> list[Path]:
    return sorted(
        file
        for file in path.rglob("*")
        if file.is_file() and file.suffix.lower() in {".png", ".jpg", ".jpeg"}
    )


class Report:
    def __init__(self) -> None:
        self.checks: dict[str, dict[str, Any]] = {}

    def add(self, name: str, passed: bool, evidence: str, required: bool = True) -> None:
        self.checks[name] = {
            "passed": passed,
            "required": required,
            "evidence": evidence,
        }

    def to_dict(self, started_at: str, completed_at: str) -> dict[str, Any]:
        failed_required = [
            name
            for name, check in self.checks.items()
            if check["required"] and check["passed"] is not True
        ]
        return {
            "startedAt": started_at,
            "completedAt": completed_at,
            "passed": not failed_required,
            "failedRequiredChecks": failed_required,
            "checks": self.checks,
        }


def build_report(args: argparse.Namespace) -> dict[str, Any]:
    started_at = utc_now()
    root = Path(args.repo_root).resolve()
    report = Report()

    app_icon_set = root / args.app_icon_set
    app_icon_contents = read_json(app_icon_set / "Contents.json")
    app_icon_images = app_icon_contents.get("images", []) if isinstance(app_icon_contents.get("images", []), list) else []
    app_store_icon_entry = next(
        (
            entry
            for entry in app_icon_images
            if isinstance(entry, dict)
            and entry.get("filename")
            and entry.get("size") == "1024x1024"
            and entry.get("idiom") in {"universal", "ios-marketing"}
        ),
        None,
    )
    report.add(
        "appIconCatalogHas1024Entry",
        app_store_icon_entry is not None,
        "1024x1024 AppIcon entry found" if app_store_icon_entry else "missing 1024x1024 AppIcon entry",
    )

    icon_filename = app_store_icon_entry.get("filename", "") if isinstance(app_store_icon_entry, dict) else ""
    icon_path = app_icon_set / icon_filename if icon_filename else app_icon_set / "AppIcon-1024.png"
    icon_info = png_info(icon_path)
    icon_size = (icon_info.get("width"), icon_info.get("height"))
    report.add(
        "appIcon1024PngValid",
        icon_info.get("valid") is True and icon_size == (1024, 1024),
        f"{icon_path}: {icon_info}",
    )
    report.add(
        "appIconHasNoAlpha",
        icon_info.get("valid") is True and icon_info.get("colorType") not in PNG_COLOR_TYPES_WITH_ALPHA,
        f"PNG colorType={icon_info.get('colorType', '<invalid>')}",
    )

    final_screenshot_dir = root / args.final_screenshot_dir
    screenshots = screenshot_files(final_screenshot_dir)
    report.add(
        "finalScreenshotsCount",
        len(screenshots) >= args.min_screenshots,
        f"{len(screenshots)} screenshots under {args.final_screenshot_dir}",
    )
    invalid_screenshots: list[str] = []
    screenshot_details: list[dict[str, Any]] = []
    for screenshot in screenshots:
        info = png_info(screenshot) if screenshot.suffix.lower() == ".png" else {"valid": False, "error": "only PNG screenshots are allowed for this gate"}
        size = (info.get("width"), info.get("height"))
        detail = {
            "path": str(screenshot.relative_to(root)),
            "width": info.get("width"),
            "height": info.get("height"),
            "colorType": info.get("colorType"),
        }
        screenshot_details.append(detail)
        if info.get("valid") is not True or size not in ACCEPTED_IPHONE_SCREENSHOT_SIZES:
            invalid_screenshots.append(f"{screenshot.name}: {info}")
    report.add(
        "finalScreenshotsAcceptedSizes",
        not invalid_screenshots and bool(screenshots),
        "all screenshot sizes accepted: " + json.dumps(screenshot_details, ensure_ascii=False)
        if not invalid_screenshots and screenshots
        else "; ".join(invalid_screenshots) or "no screenshots",
    )
    report.add(
        "finalScreenshotsNoBabyPhotoNames",
        not any("baby" in screenshot.name.lower() or "宝宝" in screenshot.name for screenshot in screenshots),
        "screenshot filenames do not suggest real baby photos",
    )

    return report.to_dict(started_at, utc_now())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=str(repo_root()))
    parser.add_argument("--app-icon-set", default="App/iOS/XiaoNaiPing/Assets.xcassets/AppIcon.appiconset")
    parser.add_argument("--final-screenshot-dir", default="Docs/08_Release/AppStoreEvidence/10-final-screenshots")
    parser.add_argument("--min-screenshots", type=int, default=5)
    parser.add_argument("--output", default="Backend/proof/app-store-assets.json")
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()

    result = build_report(args)
    output_path = Path(args.output)
    if not output_path.is_absolute():
        output_path = Path(args.repo_root) / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if result["passed"]:
        print(f"App Store assets passed: {output_path}")
        return

    failed = ", ".join(result["failedRequiredChecks"])
    print(f"App Store assets incomplete: {output_path}")
    print(f"failed required checks: {failed}")
    if not args.allow_incomplete:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
