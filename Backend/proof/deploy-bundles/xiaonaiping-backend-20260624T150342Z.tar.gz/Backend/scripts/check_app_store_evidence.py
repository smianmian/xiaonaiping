#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EVIDENCE_ROOT = Path("Docs/08_Release/AppStoreEvidence")

REQUIRED_EVIDENCE = {
    "companyAccount": {
        "patterns": ["01-company-account.*"],
        "description": "深圳市闪现生活科技有限公司 App Store Connect 主体证据",
    },
    "mainlandAvailability": {
        "patterns": ["02-mainland-availability.*"],
        "description": "App Store Connect 只选择中国大陆可售地区",
    },
    "mainlandFiling": {
        "patterns": ["03-app-filing.*"],
        "description": "中国大陆 APP 备案或适用判断证据",
    },
    "privacyLabel": {
        "patterns": ["04-privacy-label.*"],
        "description": "App Store Connect 隐私标签截图或导出",
    },
    "signedArchive": {
        "patterns": ["05-signed-archive.*"],
        "description": "App Store Distribution Archive 成功证据",
    },
    "testFlight": {
        "patterns": ["06-testflight.*"],
        "description": "TestFlight 构建和测试状态证据",
    },
    "smsProvider": {
        "patterns": ["07-sms-provider.*"],
        "description": "真实短信签名、模板和验证码发送成功证据",
    },
    "wechatOpenPlatform": {
        "patterns": ["08-wechat-open-platform.*"],
        "description": "微信开放平台移动应用、Bundle ID、URL Scheme / Universal Link 配置证据",
    },
    "huaweiObsPolicy": {
        "patterns": ["09-obs-policy.*"],
        "description": "华为云 OBS bucket、生命周期、加密和删除验证证据",
    },
    "finalScreenshots": {
        "patterns": ["10-final-screenshots/*.png", "10-final-screenshots/*.jpg", "10-final-screenshots/*.jpeg"],
        "description": "最终 App Store 截图，不使用真实宝宝照片",
        "minFiles": 5,
    },
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def matching_files(root: Path, patterns: list[str]) -> list[Path]:
    files: list[Path] = []
    for pattern in patterns:
        files.extend(path for path in root.glob(pattern) if path.is_file() and path.stat().st_size > 0)
    return sorted(set(files))


def build_report(root: Path) -> dict[str, Any]:
    evidence_root = root / EVIDENCE_ROOT
    checks: dict[str, dict[str, Any]] = {}
    for name, spec in REQUIRED_EVIDENCE.items():
        files = matching_files(evidence_root, spec["patterns"])
        min_files = int(spec.get("minFiles", 1))
        checks[name] = {
            "passed": len(files) >= min_files,
            "description": spec["description"],
            "patterns": [str(EVIDENCE_ROOT / pattern) for pattern in spec["patterns"]],
            "minFiles": min_files,
            "files": [str(path.relative_to(root)) for path in files],
        }

    missing = [name for name, check in checks.items() if not check["passed"]]
    return {
        "startedAt": utc_now(),
        "completedAt": utc_now(),
        "ready": not missing,
        "missingEvidence": missing,
        "evidenceRoot": str(EVIDENCE_ROOT),
        "checks": checks,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=str(repo_root()))
    parser.add_argument("--output", default="Backend/proof/app-store-evidence.json")
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()

    root = Path(args.repo_root).resolve()
    result = build_report(root)
    output_path = Path(args.output)
    if not output_path.is_absolute():
        output_path = root / output_path
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if result["ready"]:
        print(f"App Store evidence passed: {output_path}")
        return

    missing = ", ".join(result["missingEvidence"])
    print(f"App Store evidence incomplete: {output_path}", file=sys.stderr)
    print(f"missing evidence: {missing}", file=sys.stderr)
    if not args.allow_incomplete:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
