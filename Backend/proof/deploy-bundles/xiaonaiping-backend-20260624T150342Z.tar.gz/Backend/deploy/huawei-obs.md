# Huawei Cloud OBS Handoff

This handoff keeps production secrets out of the repository. Use it only in the private deployment workspace.

## Backend Mode

Set:

```bash
XNP_STORAGE_BACKEND=huawei_obs
HUAWEI_OBS_ACCESS_KEY_ID=...
HUAWEI_OBS_SECRET_ACCESS_KEY=...
HUAWEI_OBS_ENDPOINT=...
HUAWEI_OBS_BUCKET=...
HUAWEI_OBS_PREFIX=xiaonaiping
```

Install the optional SDK:

```bash
pip install -r Backend/requirements-obs.txt
```

## Bucket Rules

1. Use a private bucket.
2. Do not allow public object listing or public object reads.
3. Do not place baby names, birthdays, notes, or original filenames in object keys.
4. Keep server-side AK/SK only on the backend host or secret manager.
5. Keep iOS clients on the first-party API; do not give the app direct OBS write credentials.
6. Verify account deletion removes all objects under `HUAWEI_OBS_PREFIX/{accountId}/`.
7. Run `python3 Backend/scripts/verify_storage_backend.py --output Backend/proof/storage-backend.json` with the production private env loaded.

## Evidence Required Before App Store Submit

1. API health check over HTTPS.
2. Release-flow verification against the production API:
   `python3 Backend/scripts/verify_remote_api.py --base-url https://api.mewpow.com/xiaonaiping --output Backend/proof/remote-api.json`
3. Production readiness verification:
   `python3 Backend/scripts/check_production_readiness.py --base-url https://api.mewpow.com/xiaonaiping --require-huawei-obs --require-screenshots --require-app-store-evidence --live-check --output Backend/proof/production-readiness.json`
4. Object storage verification:
   `python3 Backend/scripts/verify_storage_backend.py --output Backend/proof/storage-backend.json`
5. Auth provider verification:
   `python3 Backend/scripts/verify_auth_providers.py --live-check --output Backend/proof/auth-providers.json`
6. Diagnostics redaction verification:
   `python3 Backend/scripts/check_diagnostics_redaction.py --output Backend/proof/diagnostics-redaction.json`
7. Public pages verification:
   `python3 Backend/scripts/check_public_pages.py --output Backend/proof/public-pages.json`
8. Review Notes verification:
   `python3 Backend/scripts/check_review_notes.py --output Backend/proof/review-notes.json`
9. Legal drafts verification:
   `python3 Backend/scripts/check_legal_drafts.py --output Backend/proof/legal-drafts.json`
10. Universal Links verification:
   `python3 Backend/scripts/check_universal_links.py --output Backend/proof/universal-links.json`
11. Secret-free deployment bundle:
   `python3 Backend/scripts/build_deploy_bundle.py --output-dir Backend/proof/deploy-bundles`
12. OBS lifecycle and backup settings screenshot or exported policy.
13. Deletion proof showing account backup and photo objects are gone after `DELETE /v1/account`.
